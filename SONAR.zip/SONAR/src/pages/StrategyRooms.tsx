import React from 'react';

const StrategyRooms: React.FC = () => {
    return (
        <div className="strategy-rooms">
            <h1>Strategy Rooms</h1>
            <p>Welcome to the Strategy Rooms. This section is restricted to strategists and decision-makers.</p>
            {/* Add components related to strategy rooms here */}
        </div>
    );
};

export default StrategyRooms;